import 'package:flutter/material.dart';
import 'widgets.dart';
import 'helpers.dart';

class Page_pagehome extends StatelessWidget {
  final Function(int)? onTabTapped;
  final int currentTabIndex;
  const Page_pagehome({super.key, this.onTabTapped, this.currentTabIndex = 0});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: SafeArea(
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned(
              left: 12,
              top: 202,
              width: 200,
              height: 80,
              child: TextElement(properties: const {'text': 'Salom, dunyo!', 'textColor': '#111827', 'fontSize': '16', 'fontWeight': 'normal', 'alignment': 'left', 'x': '12', 'y': '202', 'area': 'body', 'width': '200', 'height': '80', }),
            ),
            Positioned(
              left: 64,
              top: 84,
              width: 200,
              height: 80,
              child: InputElement(properties: const {'placeholder': 'Matn kiriting...', 'borderColor': '#d1d5db', 'borderRadius': '12', 'fontSize': '16', 'width': '200', 'bgColor': '#ffffff', 'x': '64', 'y': '84', 'area': 'body', 'height': '80', }),
            ),
            Positioned(
              left: 0,
              top: 361,
              width: 200,
              height: 80,
              child: ButtonElement(properties: const {'text': 'Tugma', 'bgColor': '#3b82f6', 'textColor': '#ffffff', 'fontSize': '16', 'borderRadius': '12', 'width': '200', 'fontWeight': 'semibold', 'paddingH': '16', 'paddingV': '14', 'x': '0', 'y': '361', 'area': 'body', 'height': '80', }),
            ),
          ],
        ),
      ),
    );
  }
}

