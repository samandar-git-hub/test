import 'package:flutter/material.dart';
import 'widgets.dart';
import 'helpers.dart';

class Page_pagehome extends StatelessWidget {
  final Function(int)? onTabTapped;
  final int currentTabIndex;
  const Page_pagehome({super.key, this.onTabTapped, this.currentTabIndex = 0});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: SafeArea(
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned(
              left: 88,
              top: 113,
              width: 200,
              height: 80,
              child: ImageElement(properties: const {'src': '', 'alt': 'Rasm tavsifi', 'borderRadius': '12', 'width': '200', 'fit': 'cover', 'x': '88', 'y': '113', 'area': 'body', 'height': '80', }),
            ),
            Positioned(
              left: 21,
              top: 180,
              width: 200,
              height: 80,
              child: TextElement(properties: const {'text': 'Salom, dunyo!', 'textColor': '#111827', 'fontSize': '16', 'fontWeight': 'normal', 'alignment': 'left', 'x': '21', 'y': '180', 'area': 'body', 'width': '200', 'height': '80', }),
            ),
            Positioned(
              left: 42,
              top: 362,
              width: 200,
              height: 80,
              child: InputElement(properties: const {'placeholder': 'Matn kiriting...', 'borderColor': '#d1d5db', 'borderRadius': '12', 'fontSize': '16', 'width': '200', 'bgColor': '#ffffff', 'x': '42', 'y': '362', 'area': 'body', 'height': '80', }),
            ),
          ],
        ),
      ),
    );
  }
}

