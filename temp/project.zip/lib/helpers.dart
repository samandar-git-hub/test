import 'package:flutter/material.dart';

Color parseHexColor(String hex) {
  hex = hex.replaceAll('#', '');
  if (hex.length == 6) {
    hex = 'FF$hex';
  }
  return Color(int.parse(hex, radix: 16));
}

FontWeight parseFontWeight(String weight) {
  switch (weight) {
    case 'w100': return FontWeight.w100;
    case 'w200': return FontWeight.w200;
    case 'w300': return FontWeight.w300;
    case 'w400': return FontWeight.w400;
    case 'w500': return FontWeight.w500;
    case 'w600': return FontWeight.w600;
    case 'w700': return FontWeight.w700;
    case 'w800': return FontWeight.w800;
    case 'w900': return FontWeight.w900;
    default: return FontWeight.w400;
  }
}

TextAlign parseTextAlign(String alignment) {
  switch (alignment) {
    case 'left': return TextAlign.left;
    case 'center': return TextAlign.center;
    case 'right': return TextAlign.right;
    default: return TextAlign.left;
  }
}
