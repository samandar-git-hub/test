import 'dart:convert';
import 'dart:io' as io;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'helpers.dart';

class ButtonElement extends StatelessWidget {
  final Map<String, String> properties;
  const ButtonElement({super.key, required this.properties});

  @override
  Widget build(BuildContext context) {
    final p = properties;
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(
        horizontal: double.tryParse(p['paddingH'] ?? '16') ?? 16,
        vertical: double.tryParse(p['paddingV'] ?? '14') ?? 14,
      ),
      decoration: BoxDecoration(
        color: parseHexColor(p['bgColor'] ?? '#3b82f6'),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(double.tryParse(p['radiusTopLeft'] ?? p['borderRadius'] ?? '12') ?? 12),
          topRight: Radius.circular(double.tryParse(p['radiusTopRight'] ?? p['borderRadius'] ?? '12') ?? 12),
          bottomLeft: Radius.circular(double.tryParse(p['radiusBottomLeft'] ?? p['borderRadius'] ?? '12') ?? 12),
          bottomRight: Radius.circular(double.tryParse(p['radiusBottomRight'] ?? p['borderRadius'] ?? '12') ?? 12),
        ),
        boxShadow: [
          BoxShadow(
            color: parseHexColor(p['bgColor'] ?? '#3b82f6').withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Center(
        child: Text(
          p['text'] ?? 'Tugma',
          style: GoogleFonts.inter(
            fontSize: double.tryParse(p['fontSize'] ?? '16') ?? 16,
            fontWeight: parseFontWeight(p['fontWeight'] ?? 'semibold'),
            color: parseHexColor(p['textColor'] ?? '#ffffff'),
          ),
        ),
      ),
    );
  }
}

class InputElement extends StatelessWidget {
  final Map<String, String> properties;
  const InputElement({super.key, required this.properties});

  @override
  Widget build(BuildContext context) {
    final p = properties;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: parseHexColor(p['bgColor'] ?? '#ffffff'),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(double.tryParse(p['radiusTopLeft'] ?? p['borderRadius'] ?? '12') ?? 12),
          topRight: Radius.circular(double.tryParse(p['radiusTopRight'] ?? p['borderRadius'] ?? '12') ?? 12),
          bottomLeft: Radius.circular(double.tryParse(p['radiusBottomLeft'] ?? p['borderRadius'] ?? '12') ?? 12),
          bottomRight: Radius.circular(double.tryParse(p['radiusBottomRight'] ?? p['borderRadius'] ?? '12') ?? 12),
        ),
        border: Border.all(color: parseHexColor(p['borderColor'] ?? '#d1d5db'), width: 1),
      ),
      child: TextField(
        decoration: InputDecoration(
          hintText: p['placeholder'] ?? 'Matn kiriting...',
          hintStyle: GoogleFonts.inter(
            fontSize: double.tryParse(p['fontSize'] ?? '16') ?? 16,
            color: const Color(0xFF9ca3af),
          ),
          border: InputBorder.none,
          isDense: true,
          contentPadding: EdgeInsets.zero,
        ),
        style: GoogleFonts.inter(
          fontSize: double.tryParse(p['fontSize'] ?? '16') ?? 16,
        ),
      ),
    );
  }
}

class TextElement extends StatelessWidget {
  final Map<String, String> properties;
  const TextElement({super.key, required this.properties});

  @override
  Widget build(BuildContext context) {
    final p = properties;
    return Text(
      p['text'] ?? 'Salom, dunyo!',
      textAlign: parseTextAlign(p['alignment'] ?? 'left'),
      style: GoogleFonts.inter(
        fontSize: double.tryParse(p['fontSize'] ?? '16') ?? 16,
        fontWeight: parseFontWeight(p['fontWeight'] ?? 'normal'),
        color: parseHexColor(p['textColor'] ?? '#111827'),
        height: 1.5,
      ),
    );
  }
}

class CardElement extends StatelessWidget {
  final Map<String, String> properties;
  const CardElement({super.key, required this.properties});

  @override
  Widget build(BuildContext context) {
    final p = properties;
    final bgColor = parseHexColor(p['bgColor'] ?? '#ffffff');
    final isDark = bgColor.computeLuminance() < 0.5;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(double.tryParse(p['paddingAll'] ?? '16') ?? 16),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(double.tryParse(p['radiusTopLeft'] ?? p['borderRadius'] ?? '16') ?? 16),
          topRight: Radius.circular(double.tryParse(p['radiusTopRight'] ?? p['borderRadius'] ?? '16') ?? 16),
          bottomLeft: Radius.circular(double.tryParse(p['radiusBottomLeft'] ?? p['borderRadius'] ?? '16') ?? 16),
          bottomRight: Radius.circular(double.tryParse(p['radiusBottomRight'] ?? p['borderRadius'] ?? '16') ?? 16),
        ),
        border: isDark ? null : Border.all(color: const Color(0xFFf3f4f6), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            p['title'] ?? 'Karta sarlavhasi',
            style: GoogleFonts.inter(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: isDark ? Colors.white : const Color(0xFF111827),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            p['description'] ?? 'Bu yerda tavsif yozing',
            style: GoogleFonts.inter(
              fontSize: 14,
              color: isDark ? Colors.white.withOpacity(0.7) : const Color(0xFF6b7280),
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}

class ImageElement extends StatelessWidget {
  final Map<String, String> properties;
  const ImageElement({super.key, required this.properties});

  Widget _buildErrorWidget(BorderRadius borderRadius) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(
        color: const Color(0xFFF0F0F0),
        borderRadius: borderRadius,
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('🖼️', style: TextStyle(fontSize: 24)),
            const SizedBox(height: 4),
            Text(
              'Rasm yuklanmadi',
              style: GoogleFonts.inter(color: const Color(0xFFAAAAAA), fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = properties;
    final src = p['src'] ?? '';
    final tl = double.tryParse(p['radiusTopLeft'] ?? p['borderRadius'] ?? '12') ?? 12;
    final tr = double.tryParse(p['radiusTopRight'] ?? p['borderRadius'] ?? '12') ?? 12;
    final bl = double.tryParse(p['radiusBottomLeft'] ?? p['borderRadius'] ?? '12') ?? 12;
    final br = double.tryParse(p['radiusBottomRight'] ?? p['borderRadius'] ?? '12') ?? 12;

    final brOnly = BorderRadius.only(
      topLeft: Radius.circular(tl),
      topRight: Radius.circular(tr),
      bottomLeft: Radius.circular(bl),
      bottomRight: Radius.circular(br),
    );

    final fitVal = p['fit'] ?? 'cover';
    BoxFit boxFit = BoxFit.cover;
    switch (fitVal) {
      case 'cover': boxFit = BoxFit.cover; break;
      case 'contain': boxFit = BoxFit.contain; break;
      case 'fill': boxFit = BoxFit.fill; break;
      case 'fitWidth': boxFit = BoxFit.fitWidth; break;
      case 'fitHeight': boxFit = BoxFit.fitHeight; break;
      case 'none': boxFit = BoxFit.none; break;
      case 'scaleDown': boxFit = BoxFit.scaleDown; break;
    }

    Widget imageWidget;
    if (src.startsWith('data:image')) {
      try {
        final base64Content = src.split(',').last;
        final bytes = base64Decode(base64Content);
        imageWidget = Image.memory(
          bytes,
          width: double.infinity,
          height: double.infinity,
          fit: boxFit,
          errorBuilder: (context, error, stackTrace) => _buildErrorWidget(brOnly),
        );
      } catch (_) {
        imageWidget = _buildErrorWidget(brOnly);
      }
    } else if (src.startsWith('http') || src.startsWith('https')) {
      imageWidget = Image.network(
        src,
        width: double.infinity,
        height: double.infinity,
        fit: boxFit,
        errorBuilder: (context, error, stackTrace) => _buildErrorWidget(brOnly),
      );
    } else if (!kIsWeb && src.isNotEmpty) {
      imageWidget = Image.file(
        io.File(src),
        width: double.infinity,
        height: double.infinity,
        fit: boxFit,
        errorBuilder: (context, error, stackTrace) => _buildErrorWidget(brOnly),
      );
    } else {
      imageWidget = Container(
        width: double.infinity,
        height: double.infinity,
        color: const Color(0xFFF0F0F0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('🖼️', style: TextStyle(fontSize: 24)),
              const SizedBox(height: 4),
              Text(
                'Rasm kiritilmagan',
                style: GoogleFonts.inter(color: const Color(0xFFAAAAAA), fontSize: 12),
              ),
            ],
          ),
        ),
      );
    }

    return ClipRRect(
      borderRadius: brOnly,
      child: imageWidget,
    );
  }
}

class DividerElement extends StatelessWidget {
  final Map<String, String> properties;
  const DividerElement({super.key, required this.properties});

  @override
  Widget build(BuildContext context) {
    final p = properties;
    return Padding(
      padding: EdgeInsets.symmetric(vertical: double.tryParse(p['marginV'] ?? '12') ?? 12),
      child: Container(
        height: double.tryParse(p['height'] ?? '1') ?? 1,
        decoration: BoxDecoration(
          color: parseHexColor(p['color'] ?? '#e5e7eb'),
          borderRadius: BorderRadius.circular(50),
        ),
      ),
    );
  }
}

class ToggleElement extends StatefulWidget {
  final Map<String, String> properties;
  const ToggleElement({super.key, required this.properties});

  @override
  State<ToggleElement> createState() => _ToggleElementState();
}

class _ToggleElementState extends State<ToggleElement> {
  bool _isOn = false;

  @override
  void initState() {
    super.initState();
    _isOn = widget.properties['defaultState'] == 'on';
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.properties;
    final activeColor = parseHexColor(p['activeColor'] ?? '#3b82f6');

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          p['label'] ?? 'Bildirishnomalar',
          style: GoogleFonts.inter(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: const Color(0xFF374151),
          ),
        ),
        GestureDetector(
          onTap: () {
            setState(() {
              _isOn = !_isOn;
            });
          },
          child: Container(
            width: 48,
            height: 28,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: _isOn ? activeColor : const Color(0xFFd1d5db),
            ),
            child: AnimatedAlign(
              duration: const Duration(milliseconds: 200),
              alignment: _isOn ? Alignment.centerRight : Alignment.centerLeft,
              child: Container(
                margin: const EdgeInsets.all(2),
                width: 24,
                height: 24,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 4,
                      offset: Offset(0, 1),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class SearchBarElement extends StatelessWidget {
  final Map<String, String> properties;
  const SearchBarElement({super.key, required this.properties});

  @override
  Widget build(BuildContext context) {
    final p = properties;
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: parseHexColor(p['bgColor'] ?? '#f3f4f6'),
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        decoration: InputDecoration(
          prefixIcon: const Icon(Icons.search_rounded, color: Color(0xFF9CA3AF), size: 18),
          hintText: p['placeholder'] ?? 'Qidirish...',
          hintStyle: GoogleFonts.inter(fontSize: 13, color: const Color(0xFF9CA3AF)),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 12),
        ),
        style: GoogleFonts.inter(fontSize: 13),
      ),
    );
  }
}
